# Linux for AI-ML Systems

Transformed 2 Succeed (T2S) · Emmanuel Naweji

Every AI model lives on a Linux machine. Learn to read the machine, and you can keep the model alive.

| Module | Sticky idea | Lab |
|---|---|---|
| 1 · The Machine Under Your Model | **File at rest. Process at work.** | Map a model server you have never seen and find 3 problems |
| 2 · Feed the Model | **Pre-flight: Space · Owner · Secret** | Fix a training job that will not start |
| 3 · Keep It Running | **Don't guess. Grep.** | Catch a silent out-of-memory kill and fix it |

## Pick your Linux (one time)

- **Any computer, zero install:** GitHub Codespaces (open this repo, Code → Codespaces → Create)
- **Windows:** `wsl --install -d Ubuntu-24.04` in PowerShell (Admin), restart, open Ubuntu
- **Mac:** `brew install --cask multipass` then `multipass launch 24.04 --name ailab` and `multipass shell ailab`

Then:

```bash
git clone https://github.com/Here2ServeU/linux-for-ai-ml
cd linux-for-ai-ml
bash setup/doctor.sh
```

## Labs

```bash
# Module 1
cd modules/module-1/scripts && python3 make_server.py && cd ~/ai-server && cat README-FIRST.txt

# Module 2
cd modules/module-2/scripts && python3 make_job.py && cd ~/train-job && python3 train.py

# Module 3
cd modules/module-3/scripts && python3 serve.py &
```

Lab sizes are scaled down: 1 MB in the lab stands for 1 GB on a real server. No GPU needed;
Module 3 reads a sample `nvidia-smi` output in `samples/`.

Reset any lab with `--reset` (Modules 1 and 2).
