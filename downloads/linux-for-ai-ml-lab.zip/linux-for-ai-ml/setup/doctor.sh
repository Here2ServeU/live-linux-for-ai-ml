#!/usr/bin/env bash
# Linux for AI-ML Systems - environment check.
# Run:  bash setup/doctor.sh
ok()   { printf "  [ OK ]  %s\n" "$1"; }
warn() { printf "  [WARN]  %s\n" "$1"; }

echo "Linux for AI-ML Systems - doctor"
echo "--------------------------------"
if [ "$(uname -s)" = "Linux" ]; then ok "Linux kernel $(uname -r)"; else warn "Not Linux ($(uname -s)). Use Codespaces, WSL or Multipass."; fi
if [ -r /etc/os-release ]; then . /etc/os-release; ok "Distro: ${PRETTY_NAME}"; fi
ok "Shell: ${SHELL:-unknown}   User: $(whoami)"
if command -v python3 >/dev/null; then ok "$(python3 --version)"; else warn "python3 missing: sudo apt install -y python3"; fi
if command -v git >/dev/null; then ok "$(git --version)"; else warn "git missing: sudo apt install -y git"; fi
FREE_GB=$(df -Pk "$HOME" | awk 'NR==2 {printf "%d", $4/1024/1024}')
if [ "${FREE_GB:-0}" -ge 2 ]; then ok "Free disk in \$HOME: ${FREE_GB} GB"; else warn "Only ${FREE_GB} GB free in \$HOME (labs need about 1 GB)"; fi
if command -v nvidia-smi >/dev/null; then ok "NVIDIA GPU tools found"; else ok "No GPU here - that's fine. Module 3 uses a sample nvidia-smi file."; fi
echo "--------------------------------"
echo "If every line says OK, you are ready."
