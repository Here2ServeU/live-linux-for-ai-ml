#!/usr/bin/env python3
"""Module 3 lab: a pretend LLM inference server.

Each request adds to an in-memory 'KV cache'. With max_cache_mb=0 the cache
never shrinks, so memory climbs until something kills the process.
Run:  python3 serve.py &
"""
import http.server, json, os, signal, sys, time
from pathlib import Path

HERE = Path(__file__).resolve().parent
LOG = HERE / "logs" / "server.log"
PIDFILE = HERE / "server.pid"
CONF = {}
for line in (HERE / "server.conf").read_text().splitlines():
    line = line.strip()
    if line and not line.startswith("#") and "=" in line:
        k, v = line.split("=", 1)
        CONF[k.strip()] = v.strip()
PORT = int(CONF.get("port", 8080))
MAX_CACHE_MB = int(CONF.get("max_cache_mb", 0))
cache = []   # list of bytearrays, 1 MB per 'token block'

def log(level, msg):
    LOG.parent.mkdir(exist_ok=True)
    with open(LOG, "a") as f:
        f.write(f"{time.strftime('%Y-%m-%d %H:%M:%S')} {level:<5} {msg}\n")

def cache_mb():
    return len(cache)

class Handler(http.server.BaseHTTPRequestHandler):
    def log_message(self, *a):  # keep the terminal quiet
        pass
    def _send(self, code, body):
        data = json.dumps(body).encode()
        self.send_response(code)
        self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(data)))
        self.end_headers()
        self.wfile.write(data)
    def do_GET(self):
        if self.path == "/health":
            self._send(200, {"status": "ok", "pid": os.getpid(), "cache_mb": cache_mb()})
        else:
            self._send(404, {"error": "try /health or POST /generate"})
    def do_POST(self):
        n = int(self.headers.get("Content-Length", 0))
        req = json.loads(self.rfile.read(n) or b"{}")
        tokens = int(req.get("prompt_tokens", 1000))
        blocks = max(1, tokens // 1000) * 8          # 8 MB of cache per 1,000 tokens
        for _ in range(blocks):
            cache.append(bytearray(1024 * 1024))
            cache[-1][::4096] = b"x" * len(cache[-1][::4096])   # touch pages so RSS grows
        while MAX_CACHE_MB and cache_mb() > MAX_CACHE_MB:
            cache.pop(0)                               # evict oldest
        log("INFO", f"generate prompt_tokens={tokens} cache_mb={cache_mb()}")
        self._send(200, {"output": "pretend answer", "cache_mb": cache_mb()})

def shutdown(signum, frame):
    log("INFO", f"received SIGTERM - finishing requests, saving state, shutting down cleanly")
    PIDFILE.unlink(missing_ok=True)
    sys.exit(0)

def main():
    signal.signal(signal.SIGTERM, shutdown)
    PIDFILE.write_text(str(os.getpid()))
    limit = f"{MAX_CACHE_MB} MB" if MAX_CACHE_MB else "no limit"
    log("INFO", f"server starting pid={os.getpid()} port={PORT} max_cache={limit}")
    srv = http.server.HTTPServer(("127.0.0.1", PORT), Handler)
    log("INFO", "model loaded, ready")
    print(f"serve.py running as PID {os.getpid()} on http://127.0.0.1:{PORT}  (logs: logs/server.log)")
    srv.serve_forever()

if __name__ == "__main__":
    main()
