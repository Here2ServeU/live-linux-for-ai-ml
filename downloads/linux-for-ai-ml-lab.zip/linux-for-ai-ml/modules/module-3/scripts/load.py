#!/usr/bin/env python3
"""Module 3 lab: send pretend user requests to serve.py.
Run:  python3 load.py --requests 20 --tokens 4000
"""
import argparse, json, time, urllib.request, urllib.error

ap = argparse.ArgumentParser()
ap.add_argument("--requests", type=int, default=20)
ap.add_argument("--tokens", type=int, default=4000, help="prompt tokens per request")
ap.add_argument("--port", type=int, default=8080)
a = ap.parse_args()

for i in range(1, a.requests + 1):
    body = json.dumps({"prompt_tokens": a.tokens}).encode()
    req = urllib.request.Request(f"http://127.0.0.1:{a.port}/generate", data=body,
                                 headers={"Content-Type": "application/json"})
    try:
        with urllib.request.urlopen(req, timeout=5) as r:
            out = json.loads(r.read())
        print(f"request {i:2d}: ok   cache={out['cache_mb']} MB")
    except (urllib.error.URLError, ConnectionError, OSError) as e:
        print(f"request {i:2d}: FAILED  ({e.__class__.__name__}) - is the server still running?")
    time.sleep(0.4)
