nvidia-smi.txt is an example of what the real `nvidia-smi` command prints on a
machine with one NVIDIA GPU. Labs run without a GPU, so we read this file instead.
On a GPU machine, run the real thing:
    nvidia-smi
    watch -n 1 nvidia-smi
    nvidia-smi --query-gpu=name,memory.used,memory.total,utilization.gpu --format=csv
