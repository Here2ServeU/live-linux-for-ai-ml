#!/usr/bin/env bash
# Module 3 lab: a stand-in for the Linux OOM killer.
# On a real machine the kernel does this when RAM runs out, and writes the
# reason to the kernel log (read it with: sudo dmesg  or  journalctl -k).
# Here we watch serve.py and use the same wording, in logs/kernel-sim.log.
# Run:  ./watchdog.sh &
cd "$(dirname "$0")"
LIMIT_MB=${LIMIT_MB:-200}
mkdir -p logs
echo "watchdog: memory limit for serve.py is ${LIMIT_MB} MB"
while true; do
  if [ -f server.pid ]; then
    PID=$(cat server.pid)
    if kill -0 "$PID" 2>/dev/null; then
      RSS_KB=$(ps -o rss= -p "$PID" | tr -d ' ')
      if [ -n "$RSS_KB" ] && [ "$RSS_KB" -gt $((LIMIT_MB * 1024)) ]; then
        kill -9 "$PID"
        echo "$(date '+%b %d %H:%M:%S') lab-kernel: Out of memory: Killed process ${PID} (python3) anon-rss:${RSS_KB}kB" >> logs/kernel-sim.log
        rm -f server.pid
      fi
    fi
  fi
  sleep 0.5
done
