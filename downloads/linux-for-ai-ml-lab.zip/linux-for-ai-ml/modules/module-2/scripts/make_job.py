#!/usr/bin/env python3
"""Module 2 lab: build a training job that will NOT start until you fix it.

Run:   python3 make_job.py           (creates ~/train-job)
Reset: python3 make_job.py --reset

The job has three hidden problems: Space, Owner and Secret.
Sizes are scaled: the lab disk quota is 100 MB (think: a 100 GB disk).
"""
import argparse, json, os, random, shutil
from pathlib import Path

MB = 1024 * 1024
HERE = Path(__file__).resolve().parent

def blob(path, mb, seed):
    rng = random.Random(seed)
    path.parent.mkdir(parents=True, exist_ok=True)
    with open(path, "wb") as f:
        f.write(rng.randbytes(int(mb * MB)))

def build(root: Path):
    # 1. SPACE: last month's checkpoints nobody deleted (8 x 10 MB = 80 MB of a 100 MB quota)
    for i in range(1, 9):
        blob(root / "checkpoints" / "old-run" / f"epoch-{i:02d}.ckpt", 10, seed=i)
    blob(root / "checkpoints" / "best" / "best.ckpt", 3, seed=99)

    # 2. OWNER: the dataset exists, but nobody can read it
    data = root / "data" / "tickets.jsonl"
    data.parent.mkdir(parents=True, exist_ok=True)
    rng = random.Random(7)
    with open(data, "w") as f:
        for i in range(1, 2001):
            f.write(json.dumps({"id": i, "text": f"ticket {i}", "label": rng.choice(["urgent", "normal"])}) + "\n")
    os.chmod(data, 0o000)

    # 3. SECRET: a token file that everyone on the machine can read
    env = root / ".env"
    env.write_text("# never commit this file\nexport LAB_HF_TOKEN=hf_lab_example_not_a_real_token\n")
    os.chmod(env, 0o644)

    shutil.copy(HERE / "train.py", root / "train.py")
    (root / "README-FIRST.txt").write_text(
        "This training job will not start.\n"
        "Run:  python3 train.py\n"
        "Read what it says, fix one thing at a time, run it again.\n"
        "Pre-flight: Space - Owner - Secret.\n")

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--dir", default=str(Path.home() / "train-job"))
    ap.add_argument("--reset", action="store_true")
    a = ap.parse_args()
    root = Path(a.dir)
    if root.exists():
        if not a.reset:
            print(f"{root} already exists. Use --reset to rebuild it.")
            return
        for p in root.rglob("*"):
            try: os.chmod(p, 0o700 if p.is_dir() else 0o600)
            except OSError: pass
        shutil.rmtree(root)
    build(root)
    print(f"Built {root}")
    print("Next:  cd ~/train-job && python3 train.py")

if __name__ == "__main__":
    main()
