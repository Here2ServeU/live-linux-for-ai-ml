#!/usr/bin/env python3
"""Module 2 lab: a pretend training job with a real pre-flight check.

It checks three things before it spends a single (pretend) GPU hour:
  SPACE   - is there room for the new checkpoints?   (lab quota: 100 MB)
  OWNER   - can this user read the dataset?
  SECRET  - is the token loaded, and is the secret file private?
"""
import os, stat, sys, time
from pathlib import Path

ROOT = Path(__file__).resolve().parent
QUOTA_MB = 100      # pretend disk: think 100 GB
NEED_MB = 30        # this run writes 3 checkpoints x 10 MB
DATA = ROOT / "data" / "tickets.jsonl"
ENV = ROOT / ".env"
MB = 1024 * 1024

def used_mb():
    total = 0
    for p in ROOT.rglob("*"):
        try:
            if p.is_file():
                total += p.stat().st_size
        except OSError:
            pass
    return total / MB

def check_space():
    used = used_mb()
    free = QUOTA_MB - used
    if free >= NEED_MB:
        return True, f"{free:.0f} MB free, this run needs {NEED_MB} MB"
    return False, (f"only {free:.0f} MB free of {QUOTA_MB} MB, this run needs {NEED_MB} MB.\n"
                   "           Find what is big:   du -sh checkpoints/* | sort -h\n"
                   "           Keep checkpoints/best. Old runs can go.")

def check_owner():
    if not DATA.exists():
        return False, f"{DATA.relative_to(ROOT)} is missing"
    mode = DATA.stat().st_mode
    readable = bool(mode & stat.S_IRUSR) and os.access(DATA, os.R_OK)
    if readable:
        return True, f"{DATA.relative_to(ROOT)} is readable by {os.environ.get('USER', 'you')}"
    return False, (f"cannot read {DATA.relative_to(ROOT)}  (permissions: {stat.filemode(mode)})\n"
                   "           Look:  ls -l data/\n"
                   "           Owner needs r. Group can read. Others get nothing.")

def check_secret():
    problems = []
    if ENV.exists() and (ENV.stat().st_mode & 0o077):
        problems.append(f".env is {stat.filemode(ENV.stat().st_mode)} - other users can read your token.\n"
                        "           Make it private: owner read/write only.")
    if not os.environ.get("LAB_HF_TOKEN"):
        problems.append("LAB_HF_TOKEN is not set in this shell.\n"
                        "           Load it:  source .env      Check it:  echo ${LAB_HF_TOKEN:0:6}")
    if problems:
        return False, "\n           ".join(problems)
    return True, "token loaded, .env is private (-rw-------)"

def main():
    print("PRE-FLIGHT  Space - Owner - Secret")
    print("-" * 46)
    results = [("SPACE", check_space()), ("OWNER", check_owner()), ("SECRET", check_secret())]
    all_ok = True
    for name, (ok, msg) in results:
        print(f"  {'PASS' if ok else 'FAIL'}  {name:<6} {msg}")
        all_ok = all_ok and ok
    print("-" * 46)
    if not all_ok:
        print("Pre-flight failed. Fix the first FAIL, then run again:  python3 train.py")
        sys.exit(1)
    print("All clear. Training...")
    out = ROOT / "checkpoints" / "new-run"
    out.mkdir(parents=True, exist_ok=True)
    rows = sum(1 for _ in open(DATA))
    for epoch in range(1, 4):
        for pct in range(0, 101, 25):
            bar = "#" * (pct // 5)
            print(f"\r  epoch {epoch}/3 [{bar:<20}] {pct:3d}%", end="", flush=True)
            time.sleep(0.15)
        with open(out / f"epoch-{epoch:02d}.ckpt", "wb") as f:
            f.write(os.urandom(10 * MB))
        print(f"  saved checkpoints/new-run/epoch-{epoch:02d}.ckpt")
    print(f"Done. Trained on {rows} tickets. 3 checkpoints saved.")
    print("Your job made it to 100%. I can do this.")

if __name__ == "__main__":
    main()
