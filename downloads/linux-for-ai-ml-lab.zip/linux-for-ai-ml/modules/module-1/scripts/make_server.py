#!/usr/bin/env python3
"""Module 1 lab: build a small, realistic 'AI model server' folder to explore.

Run:   python3 make_server.py          (creates ~/ai-server)
Reset: python3 make_server.py --reset  (deletes and rebuilds it)

Sizes are scaled down so the lab is fast: 1 MB here stands for 1 GB on a real server.
"""
import argparse, json, os, random, shutil
from pathlib import Path

MB = 1024 * 1024

def blob(path: Path, mb: float, seed: int):
    rng = random.Random(seed)
    path.parent.mkdir(parents=True, exist_ok=True)
    with open(path, "wb") as f:
        left = int(mb * MB)
        while left > 0:
            n = min(left, MB)
            f.write(rng.randbytes(n))
            left -= n

def text(path: Path, body: str):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(body)

def build(root: Path):
    m = root / "models"
    # 8B parameters x 2 bytes (fp16) = ~16 GB  ->  16 MB in the lab
    blob(m / "llama-3-8b" / "model.safetensors", 16, seed=8)
    text(m / "llama-3-8b" / "config.json", json.dumps({"model_type": "llama", "num_parameters": "8B", "torch_dtype": "float16"}, indent=2) + "\n")
    text(m / "llama-3-8b" / "tokenizer.json", json.dumps({"version": "1.0", "vocab_size": 128256}) + "\n")
    # 4-bit quantized copy: ~5 GB -> 5 MB
    blob(m / "llama-3-8b-q4" / "model.gguf", 5, seed=4)
    # small speech model: ~1 GB -> 1 MB
    blob(m / "whisper-small" / "model.safetensors", 1, seed=1)
    text(m / "whisper-small" / "config.json", json.dumps({"model_type": "whisper", "torch_dtype": "float32"}, indent=2) + "\n")
    # someone's 'just in case' backup: byte-for-byte the same as llama-3-8b
    blob(m / "old" / "llama-3-8b-backup" / "model.safetensors", 16, seed=8)

    # training checkpoints nobody cleaned up
    for i, step in enumerate([1000, 2000, 3000, 4000]):
        blob(root / "checkpoints" / f"step-{step}.pt", 6, seed=100 + i)

    # a small dataset
    lines = []
    topics = ["password reset", "GPU quota", "billing", "model latency", "API key"]
    rng = random.Random(42)
    for i in range(1, 501):
        lines.append(json.dumps({"id": i, "text": f"Ticket {i}: help with {rng.choice(topics)}", "label": rng.choice(["urgent", "normal"])}))
    text(root / "datasets" / "support-tickets" / "train.jsonl", "\n".join(lines[:400]) + "\n")
    text(root / "datasets" / "support-tickets" / "test.jsonl", "\n".join(lines[400:]) + "\n")

    # config with a one-character typo (llama3 vs llama-3)
    text(root / "configs" / "serve.yaml",
         "# inference server config\n"
         "port: 8080\n"
         "model_path: models/llama3-8b/model.safetensors\n"
         "max_tokens: 512\n"
         "device: cuda:0\n")
    text(root / "configs" / "speech.yaml",
         "port: 8081\n"
         "model_path: models/whisper-small/model.safetensors\n"
         "device: cpu\n")

    # logs
    log = [
        "2026-10-19 08:00:01 INFO  speech server starting on :8081",
        "2026-10-19 08:00:02 INFO  loaded models/whisper-small/model.safetensors",
        "2026-10-19 08:00:02 INFO  speech server ready",
        "2026-10-19 08:00:05 INFO  llm server starting on :8080",
        "2026-10-19 08:00:05 INFO  reading configs/serve.yaml",
        "2026-10-19 08:00:05 ERROR model file not found: models/llama3-8b/model.safetensors",
        "2026-10-19 08:00:05 INFO  llm server exited with code 1",
    ]
    text(root / "logs" / "server.log", "\n".join(log) + "\n")

    text(root / "README-FIRST.txt",
         "Welcome to ai-server.\n\n"
         "Your mission: find three problems.\n"
         "  1. What is eating the disk?\n"
         "  2. Why won't the LLM server start?\n"
         "  3. Which model file is a wasted duplicate?\n\n"
         "Sizes are scaled: 1 MB here = 1 GB on a real server.\n")

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--dir", default=str(Path.home() / "ai-server"))
    ap.add_argument("--reset", action="store_true")
    a = ap.parse_args()
    root = Path(a.dir)
    if root.exists():
        if not a.reset:
            print(f"{root} already exists. Use --reset to rebuild it.")
            return
        shutil.rmtree(root)
    build(root)
    shutil.copy(Path(__file__).resolve().parent / "check_answers.sh", root / "check_answers.sh")
    print(f"Built {root}")
    print("Next:  cd ~/ai-server && cat README-FIRST.txt")

if __name__ == "__main__":
    main()
