#!/usr/bin/env bash
# Module 1: check your three answers.
# Run from inside ~/ai-server.
# Usage: bash check_answers.sh <biggest-folder> <typo-file> <duplicate-file>
# Example: bash check_answers.sh models configs/serve.yaml models/old/llama-3-8b-backup/model.safetensors
score=0
[ "$1" = "models" ] && { echo "1. Disk:      correct - models/ is the biggest folder"; score=$((score+1)); } || echo "1. Disk:      not yet - try: du -sh ~/ai-server/* | sort -h"
[ "$2" = "configs/serve.yaml" ] && { echo "2. Startup:   correct - serve.yaml says llama3-8b, the folder is llama-3-8b"; score=$((score+1)); } || echo "2. Startup:   not yet - try: grep -rn ERROR ~/ai-server/logs"
[ "$3" = "models/old/llama-3-8b-backup/model.safetensors" ] && { echo "3. Duplicate: correct - same sha256 as models/llama-3-8b/model.safetensors"; score=$((score+1)); } || echo "3. Duplicate: not yet - try: find ~/ai-server/models -name '*.safetensors' -exec sha256sum {} +"
echo "Score: $score / 3"
[ $score -eq 3 ] && echo "You just diagnosed a server you had never seen. I can do this."
